import { Injectable } from '@angular/core';
import { Erabiltzaile } from '../../interfaces/erabiltzaile';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment.development';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private _erabiltzaile: Erabiltzaile | undefined;

  constructor(private http: HttpClient, private router: Router) { }
  login() {
	this.http.get<Erabiltzaile>(environment.baseUrl + '/erabiltzaileak/1').subscribe(
  	(erabiltzaile) => {
    	this._erabiltzaile = erabiltzaile;
    	console.log(this.erabiltzaile);
    	localStorage.setItem('erabiltzaile', JSON.stringify(this.erabiltzaile));
    	this.router.navigate(['./recetas']);
  	});
  }

  get erabiltzaile(): Erabiltzaile {
	return { ...this._erabiltzaile! };
  }

  verificaAutenticacion() {
	if (this._erabiltzaile) {
  	return true;
	}
	else {
  	this._erabiltzaile = JSON.parse(localStorage.getItem('erabiltzaile')!);
  	if (this._erabiltzaile) {
    	return true;
  	}
  	return false;
	}

  }

  logout() {
	this._erabiltzaile = undefined;
	localStorage.removeItem('erabiltzaile');
	this.router.navigate(['./auth']);
  }

}
