import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { Errezeta } from '../../interfaces/errezeta';

@Injectable({
  providedIn: 'root'
})
export class RecipesService {

  private _errezetak: Errezeta[] = [];

  constructor(private http: HttpClient) {
    this.getErrezetak();
    }

    getErrezetak() {
    this.http.get<Errezeta[]>(environment.baseUrl + '/errezetak').subscribe({
      next: (data) => { this._errezetak = data; },
      error: (err) => { console.error(err); },
      complete: () => { console.log(this._errezetak); }
    });
    }

    get errezetak() {
    return [...this._errezetak];
    }

    getErrezetaById(id: string) {
    return this._errezetak.find(errezeta => errezeta.id === id);
    }

    getErrezertakFilteredByName(termino: string) {
    if (termino)
      return this.errezetak.filter(item => item.deskribapena.toLowerCase().includes(termino.toLowerCase()));
    else
      return this.errezetak;
    }

    agregarErrezeta(errezeta: Errezeta) {

      if (!errezeta.id) {
        const maxId = this._errezetak.reduce((max, item) => Math.max(max, parseInt(item.id, 10)), 0);
        errezeta.id = (maxId + 1).toString();
      }

    return this.http.post<Errezeta>(environment.baseUrl + '/errezetak', errezeta);
    }

    actualizarErrezeta(errezeta: Errezeta) {
    return this.http.put<Errezeta>(environment.baseUrl + '/errezetak/' + errezeta.id, errezeta);
    }


    borrarErrezeta(id: string) {
      return this.http.delete(environment.baseUrl + '/errezetak/' + id);
    }
}
