
  export interface Erabiltzaile {
    id:      string;
    usuario: string;
    email:   string;
}

