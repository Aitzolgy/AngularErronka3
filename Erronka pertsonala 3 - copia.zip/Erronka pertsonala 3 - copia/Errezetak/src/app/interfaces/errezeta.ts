
  export interface Errezeta {
    id:           string;
    deskribapena: string;
    prezioa:      string;
    osagaiak:     string;
    argazkia:     string;
}
