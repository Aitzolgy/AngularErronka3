import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ImagenPipe } from '../../../pipes/imagen.pipe';
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';
import {MatFormFieldModule} from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatOptionModule } from '@angular/material/core';
import { MatButton } from '@angular/material/button';
import { RecipesService } from '../../../services/recipes/recipes.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Errezeta } from '../../../interfaces/errezeta';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-add',
  imports: [CommonModule, FormsModule, ImagenPipe, MatCardModule, MatDividerModule, MatFormFieldModule, MatSelectModule, MatIconModule, MatInputModule, MatOptionModule, MatButton,ConfirmDialogComponent],
  templateUrl: './add.component.html',
  styleUrl: './add.component.css'
})
export class AddComponent {

  constructor(private errezetaService: RecipesService,
    private activatedRoute: ActivatedRoute,
    private router: Router, private dialog: MatDialog) { }

    ngOnInit(): void {

    }



    errezeta: Errezeta = {
      id:           "",
      deskribapena: "",
      prezioa:      "",
      osagaiak:     "",
      argazkia:     ""
    }

    guardar() {
    if (!this.errezeta.id) {

      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        data: {
          title: 'Gehitu errezeta',
          message: 'Ziur zaude errezeta gehitu nahi duzula?'
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          console.log(this.errezeta);
          this.errezetaService.agregarErrezeta(this.errezeta).subscribe(resp => {
            this.errezeta = resp;
            this.errezetaService.getErrezetak();
            this.router.navigate(['/recetas/editar/' + this.errezeta.id]);
          })
        }
      });

    } else {


      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        data: {
          title: 'Editatu errezeta',
          message: 'Ziur zaude errezeta editatu nahi duzula?'
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.errezetaService.actualizarErrezeta(this.errezeta).subscribe(resp => {
            this.errezeta = resp;
            this.errezetaService.getErrezetak();
          })
        }
      });
    }
    }

    borrarErrezeta() {

      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        data: {
          title: 'Ezabatu errezeta',
          message: 'Ziur zaude errezeta ezabatu nahi duzula?'
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          const errezeta = this.errezetaService.getErrezetaById(this.activatedRoute.snapshot.params['id']);
          if (errezeta) {
            this.errezetaService.borrarErrezeta(errezeta.id!).subscribe({
              complete: () => {
                this.router.navigate(['/recetas']).then(() => {
                  window.location.reload();
                });
              }
            });
          }
        }
      });
    }

    getErrezeta(): Errezeta {
    const errezeta = this.errezetaService.getErrezetaById(this.activatedRoute.snapshot.params['id']);
    if (errezeta) {
      this.errezeta = errezeta;
    }
    return this.errezeta;
    }

}
