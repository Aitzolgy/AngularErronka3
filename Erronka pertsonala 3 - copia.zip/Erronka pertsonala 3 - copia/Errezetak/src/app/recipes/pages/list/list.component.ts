import { Component } from '@angular/core';
import { RecipesService } from '../../../services/recipes/recipes.service';
import { ErrezetaCardComponent } from '../errezeta-card/errezeta-card.component';
import { CommonModule } from '@angular/common';
import { MatDividerModule } from '@angular/material/divider';

@Component({
  selector: 'app-list',
  imports: [CommonModule,MatDividerModule,ErrezetaCardComponent],
  templateUrl: './list.component.html',
  styleUrl: './list.component.css'
})
export class ListComponent {

  constructor(private recipesService: RecipesService) { }

  get errezetak() {
	return this.recipesService.errezetak;
  }

}
