import { Component } from '@angular/core';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import {MatListModule} from '@angular/material/list';
import { RouterOutlet, RouterLink } from '@angular/router';
import { AuthService } from '../../../services/auth/auth.service';
import { RecipesService } from '../../../services/recipes/recipes.service';

@Component({
  selector: 'app-home',
  imports: [RouterLink,RouterOutlet, MatSidenavModule,MatToolbarModule,MatButtonModule,MatIconModule, MatListModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

  constructor( private authService: AuthService,private recipeService:RecipesService) {}

  logout() {
    this.authService.logout();
    }

    get auth () {
    return this.authService.erabiltzaile;
    }

    get ErrezetaKop(){
      return this.recipeService.errezetak.reduce((sum, recipe) => sum + 1, 0);
    }

}






