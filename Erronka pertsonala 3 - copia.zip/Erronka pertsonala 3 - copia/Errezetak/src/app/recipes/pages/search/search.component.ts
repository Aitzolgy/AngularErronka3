import { RecipesService } from '../../../services/recipes/recipes.service';
import { Component, OnInit } from '@angular/core';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { JsonPipe } from '@angular/common';
import { ErrezetaCardComponent } from '../errezeta-card/errezeta-card.component';
import { Errezeta } from '../../../interfaces/errezeta';
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  imports: [MatAutocompleteModule, FormsModule, CommonModule, MatFormFieldModule, MatInputModule, JsonPipe, ErrezetaCardComponent],
  styleUrls: ['./search.component.css']
})
export class SearchComponent {

  errezetaFiltrados: Errezeta[] = [];
  errezeta !: Errezeta | undefined;

  termino: string = '';

  constructor(private recipesService: RecipesService) { }

  buscar() {
    this.errezetaFiltrados = this.recipesService.getErrezertakFilteredByName(this.termino);
    console.log(this.errezetaFiltrados);
    console.log(this.termino);
    return this.errezetaFiltrados;

  }

  optionSelected(errezeta: Errezeta) {
    this.errezetaFiltrados = this.recipesService.getErrezertakFilteredByName(this.termino);
    this.errezeta = errezeta;
    this.termino = errezeta.deskribapena;
  }

}
