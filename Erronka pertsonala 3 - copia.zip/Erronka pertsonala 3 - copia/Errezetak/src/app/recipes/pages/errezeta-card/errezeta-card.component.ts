import { Component } from '@angular/core';
import { Input } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { Errezeta } from '../../../interfaces/errezeta';
import { MatButtonModule } from '@angular/material/button';
import { ImagenPipe } from '../../../pipes/imagen.pipe';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-errezeta-card',
  imports: [MatCardModule, MatButtonModule, ImagenPipe,RouterLink],
  templateUrl: './errezeta-card.component.html',
  styleUrl: './errezeta-card.component.css'
})
export class ErrezetaCardComponent {
  @Input() errezeta!: Errezeta;
}
