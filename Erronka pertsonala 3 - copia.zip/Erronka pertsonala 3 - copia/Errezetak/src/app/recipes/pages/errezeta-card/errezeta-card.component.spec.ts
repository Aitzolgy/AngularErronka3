import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ErrezetaCardComponent } from './errezeta-card.component';

describe('ErrezetaCardComponent', () => {
  let component: ErrezetaCardComponent;
  let fixture: ComponentFixture<ErrezetaCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ErrezetaCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ErrezetaCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
