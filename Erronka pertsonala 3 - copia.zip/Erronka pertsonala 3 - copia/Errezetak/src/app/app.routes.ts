import { Routes } from '@angular/router';
import { LoginComponent } from './auth/pages/login/login.component';
import { HomeComponent } from './recipes/pages/home/home.component';
import { AddComponent } from './recipes/pages/add/add.component';
import { ListComponent } from './recipes/pages/list/list.component';
import { SearchComponent } from './recipes/pages/search/search.component';
import { DetailComponent } from './recipes/pages/detail/detail.component';
import { authGuard } from './auth/guards/auth-guard.guard';


export const routes: Routes = [
  {
    path: 'auth', children: [
        { path: 'login', component: LoginComponent },
        { path: '**', redirectTo: 'login' }]
	},

  {
    path: 'recetas',
    component: HomeComponent, canActivate: [authGuard],
    children: [
      { path: 'listado', component: ListComponent },
      {path: 'agregar',component: AddComponent},
      {path: 'editar/:id',component: AddComponent},
      {path: 'buscar',component: SearchComponent},
      {path: 'id',component: DetailComponent},
      { path: '**', redirectTo: 'listado' },

]
  },
  { path: '', redirectTo: 'auth', pathMatch: 'full' },


];
