import {
  MatDivider,
  MatDividerModule
} from "./chunk-2UEJ5YK5.js";
import "./chunk-HUSDGHNW.js";
import "./chunk-5WBVX5WF.js";
import "./chunk-PLN3ND4O.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
